package model;

public class CartItem {
    private int itemId;
    private String itemName;
    private double price;
    private int quantity;

    //Constructor


    public CartItem(int itemId, String itemName, double price, int quantity) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.price = price;
        this.quantity = quantity;
    }

    //Getters

    public int getItemId() {
        return itemId;
    }

    public double getPrice() {
        return price;
    }

    public String getItemName() {
        return itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    //Setter with validation
    public void setQuantity(int quantity){
        if(quantity <= 0 ){
            throw new IllegalArgumentException("Quantity must be greater than 0");

        }
        this.quantity = quantity;
    }

    //Calculate total price
    public double getTotalPrice(){
        return price * quantity;
    }
}
