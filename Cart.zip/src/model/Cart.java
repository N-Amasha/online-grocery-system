package model;

import java.util.ArrayList;
import java.util.List;


public class Cart {

    private List<CartItem> items;

    //Constructor
    public Cart(){
        items = new ArrayList<>();
    }

    //Get all items
    public List<CartItem> getItems(){
        return items;
    }

    //Add item to cart
    public void addItem(CartItem item){
        items.add(item);
    }

    //Remove item from cart
    public void removeItem(int itemId){
        items.removeIf(i -> i.getItemId() == itemId);

    }

    //Update item quantity
    public void updateItem(int itemId , int quantity){
        for(CartItem item: items){
            if(item.getItemId() == itemId){
                item.setQuantity(quantity);
            }
        }
    }

    //Calculate total cart price
    public double getTotalPrice(){
        double total = 0 ;
        for (CartItem item : items){
            total += item.getTotalPrice();
        }
        return total;
    }
}
