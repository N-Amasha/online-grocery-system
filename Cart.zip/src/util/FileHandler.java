package util;

import model.CartItem;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class FileHandler {

    private static final String FILE_PATH = "cart.txt";

    //WRITE to file
    public static void writeCart(List<CartItem> items) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH));

        for (CartItem item : items) {
            writer.write(item.getItemId() + "," +
                    item.getItemName() + "," +
                    item.getPrice() + "," +
                    item.getQuantity());
            writer.newLine();
        }
        writer.close();
    }
        //READ from file
        public static List<CartItem> readCart() throws IOException{
            List<CartItem> items = new ArrayList<>();

            File file = new File(FILE_PATH);

            //If file doesn't exist, return empty list
           if(!file.exists()){
               return items;
           }

           BufferedReader reader = new BufferedReader(new FileReader(file));
           String line;

           while((line = reader.readLine()) != null) {
               String[] data = line.split(",");

               CartItem item = new CartItem(
                       Integer.parseInt(data[0]),
                       data[1],
                       Double.parseDouble(data[2]),
                       Integer.parseInt(data[3])

               );

               items.add(item);
           }
           reader.close();
           return items;


           }


    }

