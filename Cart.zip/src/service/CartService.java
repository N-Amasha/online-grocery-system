package service;

import model.CartItem;
import util.FileHandler;

import java.util.List;



public class CartService {

    //ADD item to cart (CREATE)
    public void addToCart(CartItem newItem) throws Exception{

        //Read existing cart items from file
        List<CartItem> items = FileHandler.readCart();

        //Check if item already exists
        boolean found = false;

        for(CartItem item : items){
            if(item.getItemId() == newItem.getItemId()){

                //If exists -- increase quantity
                int updatedQty = item.getQuantity() + newItem.getQuantity();
                item.setQuantity(updatedQty);
                found = true;
                break;


            }
        }

        //If items is new -- add it

        if(!found){
            items.add(newItem);
        }

        //Save updated list back to file
        FileHandler.writeCart(items);

    }

    //VIEW cart items (READ)
    public List <CartItem> getCartItems() throws Exception{

        return  FileHandler.readCart();
    }

    //UPDATE item quantity
    public void updateQuantity(int itemId , int newQuantity) throws Exception{

        //Read existing cart
        List <CartItem> items = FileHandler.readCart();

        //Find the item
        boolean found = false;

        for(CartItem item : items){
            if(item.getItemId() == itemId){

                //Validate quantity
                if(newQuantity <= 0 ){
                    throw new IllegalArgumentException("Quantity must be greater than 0");

                }

                //Update quantity
                item.setQuantity(newQuantity);
                found = true ;
                break;
            }
        }

        //If item not found
        if(!found){
            throw new Exception("Item not found in cart");
        }

        //Save back to file
        FileHandler.writeCart(items);
    }

    //DELETE item from cart
    public void removeItem(int itemId) throws Exception{

        //Read existing cart
        List<CartItem> items = FileHandler.readCart();

        //Find and remove item
        boolean removed = false;

        for(int i = 0 ; i < items.size() ; i ++){
            if(items.get(i).getItemId() == itemId){
                items.remove(i);
                removed = true;
                break;
            }
        }

        //If item not found
        if(!removed){
            throw new Exception("Item not found in cart");
        }

        //Save updated list
        FileHandler.writeCart(items);

    }

    //Total price
    public double getTotalPrice() throws Exception {
        double total = 0;

        for (CartItem item : FileHandler.readCart()) {
            total += item.getTotalPrice();
        }

        return total;
    }
}
