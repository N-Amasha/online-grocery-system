package test;

import model.CartItem;
import service.CartService;

public class TestCart {

    public static void main(String[] args) {

        try {
            CartService service = new CartService();

            // ADD items
            service.addToCart(new CartItem(101, "Apple", 200, 2));
            service.addToCart(new CartItem(102, "Rice", 150, 1));

            // VIEW items
            System.out.println("Cart Items:");
            for (CartItem item : service.getCartItems()) {
                System.out.println(item.getItemName() + " - Qty: " + item.getQuantity());
            }

            // UPDATE
            service.updateQuantity(101, 5);

            // DELETE
            service.removeItem(102);

            // FINAL VIEW
            System.out.println("\nAfter Update & Delete:");
            for (CartItem item : service.getCartItems()) {
                System.out.println(item.getItemName() + " - Qty: " + item.getQuantity());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}